const booksContainer = document.querySelector('.book-list');
const addBookBtn = document.getElementById('add-book-btn');
const modal = document.getElementById('modal');
const addBookForm = document.getElementById('add-book-form');
const searchBar = document.getElementById('search-bar');
const categoryFilter = document.getElementById('category-filter');
const pdfModal = document.getElementById('pdf-modal');
const pdfViewer = document.getElementById('pdf-viewer');
const closePdfBtn = document.getElementById('close-pdf-btn');
const prevPageBtn = document.getElementById('prev-page-btn');
const nextPageBtn = document.getElementById('next-page-btn');
const pageNumberDisplay = document.getElementById('page-number');

// Predefined books/topics data
let books = [
  {
    title: "Database Management System",
    category: "DBMS",
    rating: 5,
    description: "Learn the basics of database management systems with examples.",
    image: "https://i.postimg.cc/28cYZNZs/DALL-E-2025-01-16-16-27-08-A-highly-realistic-representation-of-a-Database-Management-System-DBMS.webp",
    pdf: "https://bkbhusal.com.np/wp-content/uploads/2023/08/UNIT-1-Database-Management-System-DBMS.pdf"
  },
  {
    title: "Data Communication and Networking",
    category: "DCN",
    rating: 4,
    description: "A comprehensive guide to computer networking principles.",
    image: "https://i.postimg.cc/NfLLK4nj/DALL-E-2025-01-16-16-28-10-A-realistic-depiction-of-data-communication-and-networking-showing-int.webp",
    pdf: "https://bkbhusal.com.np/wp-content/uploads/2023/08/UNIT-2-Data-Communication-and-Networking-1.pdf"
  },
  
  
   {
    title: "Web Technology II",
   
    category: "Web T",
    rating: 5,
    description: "Explore the fundamentals of Web technology and skills learning.",
    image: "https://i.postimg.cc/s1dmG8Kt/DALL-E-2025-01-16-16-30-36-A-realistic-depiction-of-a-futuristic-classroom-or-workspace-dedicated.webp",
    pdf: "https://bkbhusal.com.np/wp-content/uploads/2023/02/UNIT-3-Web-Technology-II.pdf"
  },
  {
    title: "Programming in C",
   
    category: "P in C",
    rating: 4,
    description: "Understand how to learn c programming language.",
    image: "https://i.postimg.cc/1z623kP1/C-Programming-subject-looking-realistic.jpg",
    pdf: " https://bkbhusal.com.np/wp-content/uploads/2020/09/UNIT-4-Programming-In-C.pdf"
  },
  {
    title: " Object Oriented Programming Language",
   
    category: "OOP L",
    rating: 5,
    description: "Learn the oop  with the basic step and easy to handling.",
    image: "https://i.postimg.cc/k5yqDPMt/DALL-E-2025-01-16-16-32-27-A-visually-stunning-representation-of-Object-Oriented-Programming-OOP.webp",
    pdf: " https://bkbhusal.com.np/wp-content/uploads/2020/09/UNIT-5-Object-Oriented-Programming-OOP.pdf"
  },
   {
    title: "Software Process Model",
   
    category: "SPM",
    rating: 4,
    description: "SPM is working the any devloper life cycle.",
    image: " https://i.postimg.cc/T20dx4T4/SDLC-software-process-model-subject-in-reality.jpg",
    pdf: " https://bkbhusal.com.np/wp-content/uploads/2020/09/UNIT-6-Software-Process-Model-SPM.pdf"
  },
   {
    title: "Recent Trends in Technology ",
   
    category: "R T in Tech",
    rating: 4,
    description: "Understand how the recent trend in technology working in technology field.",
    image: " https://i.postimg.cc/vHvQQSMK/Recent-Trends-in-Technology-subject-image-aesthetic.jpg",
    pdf: "https://bkbhusal.com.np/wp-content/uploads/2020/09/UNIT-7-Recent-Trends-in-Technology.pdf"
  },
  {
    title: "Project work Format 12",
   
    category: "P W F=12",
    rating: 4,
    description: " It's help to make a final project works and students are able to make project",
    image: " https://i.postimg.cc/Z55ndh53/Project-work-Format-of-class-12-student.jpg",
    pdf: "https://bkbhusal.com.np/wp-content/uploads/2023/02/PROJECT-WORK-Format-12.pdf "
  },
  {
    title: " Final Practical Viva Question",
   
    category: "F P V Q=12",
    rating: 4,
    description: " It's helps to students know that what type of question asked in the viva Orentation.",
    image: "https://i.postimg.cc/XqJnt7Fk/DALL-E-2025-01-16-13-30-19-A-realistic-scene-of-a-group-of-students-sitting-nervously-in-a-classro.webp",
    pdf: " https://bkbhusal.com.np/wp-content/uploads/2023/02/Computer-Final-Project-Work-Questions-12.pdf"
  },
  {
    title: "Programming Question and Solution",
   
    category: " P F Q A",
    rating: 4,
    description: " These are the question help to students the basic and fundamental knowleadge of C porgramming knowledge",
    image: " https://i.postimg.cc/Y0qp51VV/Programming-question-aesthetic-image.jpg",
    pdf: "https://bkbhusal.com.np/wp-content/uploads/2023/03/Programming-Solution-JavaScriptPHPC-12.pdf "
  },
  {
    title: "English book",
   
    category: "Eng",
    rating: 4,
    description: "This is a free english book pdf where student can visit or download English book.",
    image: "https://i.postimg.cc/ncGJbHDm/class-12-english-book-pdf.webp",
    pdf: "https://moecdc.gov.np/storage/gallery/1673319459.pdf "
  },
  {
    title: "Nepali Book",
   
    category: "Nep",
    rating: 4,
    description: "Understand how to secure systems and prevent cyber attacks.",
    image: " https://i.postimg.cc/RFCWxPP1/Nepali-12-perfect.png",
    pdf: "https://www.collegenp.com/uploads/pdf/2021/08/class-12-nepali-book.pdf"
  },
  {
    title: "Social Book",
   
    category: "Soc",
    rating: 4,
    description: "Understand the basic knowleadge of Society",
    image: " https://i.postimg.cc/2jvw5yT1/social-study-book-image.jpg",
    pdf: " https://moecdc.gov.np/storage/gallery/1673319495.pdf"
  },
  
  
  
  
  // Add more books here
];

// Variables to track PDF state
let currentPdf = null;
let currentPage = 1;
let totalPages = 0;

// Render books
function renderBooks(filterCategory = 'all', query = '') {
  booksContainer.innerHTML = '';
  const filteredBooks = books.filter(book => {
    const matchesCategory = filterCategory === 'all' || book.category === filterCategory;
    const matchesQuery = book.title.toLowerCase().includes(query);
    return matchesCategory && matchesQuery;
  });

  if (filteredBooks.length === 0) {
    booksContainer.innerHTML = `<p>No books found matching your criteria.</p>`;
    return;
  }

  filteredBooks.forEach(book => {
    const bookCard = document.createElement('div');
    bookCard.classList.add('book-card');
    bookCard.innerHTML = `
      <img src="${book.image}" alt="${book.title}">
      <h3>${book.title}</h3>
      <p><strong>Category:</strong> ${book.category}</p>
      <p><strong>Rating:</strong> ${book.rating}/5</p>
      <p>${book.description}</p>
      <a href="${book.pdf}" target="_blank" class="pdf-link">Download PDF</a>
      <button class="view-pdf-btn" data-pdf="${book.pdf}">View PDF</button>
    `;
    booksContainer.appendChild(bookCard);
  });

  // Add event listeners to "View PDF" buttons
  document.querySelectorAll('.view-pdf-btn').forEach(button => {
    button.addEventListener('click', (e) => {
      const pdfUrl = e.target.getAttribute('data-pdf');
      viewPdf(pdfUrl);
    });
  });
}

// Add book
addBookForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const title = document.getElementById('title').value;
  const category = document.getElementById('category').value;
  const rating = document.getElementById('rating').value;
  const description = document.getElementById('description').value;
  const imageFile = document.getElementById('image').files[0];
  const pdfFile = document.getElementById('pdf').files[0];
  const imageUrl = URL.createObjectURL(imageFile);
  const pdfUrl = URL.createObjectURL(pdfFile);

  books.push({ title, category, rating, description, image: imageUrl, pdf: pdfUrl });
  renderBooks();
  modal.classList.add('hidden');
  addBookForm.reset();
});

// Show modal
addBookBtn.addEventListener('click', () => {
  modal.classList.remove('hidden');
});

// Hide modal
modal.addEventListener('click', (e) => {
  if (e.target === modal) modal.classList.add('hidden');
});

// Filter books
searchBar.addEventListener('input', (e) => {
  renderBooks(categoryFilter.value, e.target.value.toLowerCase());
});

categoryFilter.addEventListener('change', (e) => {
  renderBooks(e.target.value, searchBar.value.toLowerCase());
});

// View PDF in modal
function viewPdf(pdfUrl) {
  pdfModal.classList.remove('hidden');
  const loadingTask = pdfjsLib.getDocument(pdfUrl);
  loadingTask.promise.then(pdf => {
    currentPdf = pdf;
    totalPages = pdf.numPages;
    currentPage = 1;
    renderPage(currentPage);
  });
}

// Render the current page
function renderPage(pageNum) {
  currentPdf.getPage(pageNum).then(page => {
    const viewport = page.getViewport({ scale: 1 });
    const context = pdfViewer.getContext('2d');
    pdfViewer.height = viewport.height;
    pdfViewer.width = viewport.width;
    page.render({ canvasContext: context, viewport: viewport });
    pageNumberDisplay.textContent = `Page ${currentPage}`;
  });
}

// Handle page navigation
prevPageBtn.addEventListener('click', () => {
  if (currentPage > 1) {
    currentPage--;
    renderPage(currentPage);
  }
});

nextPageBtn.addEventListener('click', () => {
  if (currentPage < totalPages) {
    currentPage++;
    renderPage(currentPage);
  }
});

// Close PDF modal
closePdfBtn.addEventListener('click', () => {
  pdfModal.classList.add('hidden');
  pdfViewer.width = 0;
  pdfViewer.height = 0;
});

// Initial render
renderBooks();
